install libraries:
 
pip install flask scikit-learn numpy pandas
python app.py


http://127.0.0.1:5000
